# ImPlot Example

This is a simple example demonstrating how to build ImPlot with CMake. You can build and run the example using the following commands:
```
cmake -B build && cmake --build build && build/example
```
